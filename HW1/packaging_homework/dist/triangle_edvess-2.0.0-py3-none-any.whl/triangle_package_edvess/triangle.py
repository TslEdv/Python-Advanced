def triangle_area(base, height):
    return base * height / 2
